<template>
  <div class="h-screen flex items-center justify-center">
    <slot />
  </div>
</template>

<script lang="ts" setup>

</script>

<style></style>